﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Twilio_Demo.Models;

namespace Twilio_Demo.Data
{
    public class Twilio_DemoContext : DbContext
    {
        public Twilio_DemoContext (DbContextOptions<Twilio_DemoContext> options)
            : base(options)
        {
        }

        public DbSet<Twilio_Demo.Models.Patient> Patient { get; set; }
    }
}
