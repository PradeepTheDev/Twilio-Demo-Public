﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Twilio_Demo.Models
{
    public class Patient
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Please Title")]

        public string Title { get; set; }

        [Required(ErrorMessage = "Please enter name")]
        public string HealthClientName { get; set; }


        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}", ApplyFormatInEditMode = false)]
        [Display(Name = "Date")]
        [Required(ErrorMessage = "Date of Birth is mandatory")]
        public DateTime DateOfBirth { get; set; }

        [Required(ErrorMessage = "Mobile Number is required.")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Please Enter Valid Mobile Number.")]
        public string MobileNumber { get; set; }

    }
}
