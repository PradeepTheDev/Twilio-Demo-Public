﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Twilio_Demo.Data;
using Twilio_Demo.Models;
using Twilio.Rest.Messaging.V1;
using Twilio.Rest.Api.V2010.Account;
using System.Net.Http;
using Newtonsoft.Json.Linq;


namespace Twilio_Demo
{
    public class TwilioSMS
    {
        string messageStatus;

        public async Task<string> TwilioResponseAsync(Patient patient)
        {
            //Twilio best practise to store account details in environment variable
            var accountSid = Environment.GetEnvironmentVariable("TWILIO_ACCOUNT_SID");
            var authToken = Environment.GetEnvironmentVariable("TWILIO_AUTH_TOKEN");
            var baseURL = "https://api.twilio.com/";
            var byteCredentials = accountSid + ":" + authToken;



            Twilio.TwilioClient.Init(accountSid, authToken);

            // Hardcoding phone number as only one number can be registered in Twilio Trial

            //
            var MessageContent = $"Dear {patient.Title} {patient.HealthClientName} thanks for registering in to the system";

            //Send SMS
            var message = MessageResource.Create(
            body: MessageContent,
            from: new Twilio.Types.PhoneNumber("+12674360357"),
            to: new Twilio.Types.PhoneNumber("+61470384556"));

            var GetBaseAddress = baseURL + message.Uri;

            using (System.Net.Http.HttpClient client = new System.Net.Http.HttpClient())
            {
                client.BaseAddress = new Uri(GetBaseAddress);

                HttpMessageHandler handler = new HttpClientHandler()
                {
                };
                var httpClient = new HttpClient(handler)
                {
                    BaseAddress = new Uri(GetBaseAddress),
                    Timeout = new TimeSpan(0, 2, 0)
                };

                httpClient.DefaultRequestHeaders.Add("ContentType", "application/json");

                //var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("AC204e53c30ec97a36190c8e107388bf34:392798443af527cd6dd97401975aeac7");
                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(byteCredentials);
                string val = System.Convert.ToBase64String(plainTextBytes);
                httpClient.DefaultRequestHeaders.Add("Authorization", "Basic " + val);

                HttpResponseMessage response = httpClient.GetAsync(httpClient.BaseAddress).Result;

                //Get Delivery Status
                if (response.IsSuccessStatusCode)
                {
                    var data = await response.Content.ReadAsStringAsync();
                    var myJObject = JObject.Parse(data);
                    messageStatus = myJObject.SelectToken("status").Value<string>();
                }

                //Dummy Test for multiple sms

                for (int i = 1; i < 5; i++)
                {
                    var message2 = MessageResource.Create(
                      body: MessageContent + " " + i,
                      from: new Twilio.Types.PhoneNumber("+12674360357"),
                      to: new Twilio.Types.PhoneNumber("+61470384556"));
                   

                }
            }

            
            return messageStatus;
        }

    }
}
